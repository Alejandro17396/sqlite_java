/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2a;

import java.util.ArrayList;

/**
 *
 * @author Alex
 */
public class Tienda {
    private String nombre;
    private ArrayList <Producto> misproductos= new ArrayList();

    
    public Tienda(String nombre, ArrayList<Producto> misproductos) {
        this.nombre = nombre;
        this.misproductos = misproductos;
    }

    public Tienda() {
    }

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList <Producto> getMisproductos() {
        return misproductos;
    }

    public void setMisproductos(ArrayList <Producto> misproductos) {
        this.misproductos = misproductos;
    }
    
    public int addProducto(int codigo,String nombre,String categoria, double precio){
       return 0; 
    }


    
    
}
